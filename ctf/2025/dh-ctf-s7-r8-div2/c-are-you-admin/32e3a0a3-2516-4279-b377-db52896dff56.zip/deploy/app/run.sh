#!/bin/bash
export PASSWORD=[**REDACTED**]
export FLAG=DH{fake_flag}
python3 app.py