/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package me.bechberger.ebpf.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import me.bechberger.ebpf.annotations.OriginalNames;

@Target(value={ElementType.TYPE, ElementType.TYPE_USE})
@Repeatable(value=OriginalNames.class)
@Retention(value=RetentionPolicy.RUNTIME)
@Documented
public @interface OriginalName {
    public String value();
}

