#!/bin/bash

cd /home/DronePilot/
timeout 10 qemu-aarch64 -L /usr/aarch64-linux-gnu ./prob