#!/bin/bash

${FIRMWARE_DIR}/build/px4_sitl_default/bin/px4
#cd ${FIRMWARE_DIR} && HEADLESS=1 make px4_sitl gazebo