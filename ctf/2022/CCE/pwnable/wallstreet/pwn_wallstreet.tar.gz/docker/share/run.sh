#!/bin/bash
cd /home/ctf
./run_qemu.sh