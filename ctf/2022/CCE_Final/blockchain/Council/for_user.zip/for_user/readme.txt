RedCouncil: 0xBb0E5991c25A2cEd5e9d3A23f133271aEDb5ABf0
RedCouncilToken: 0x17D0d78e3D5791981E57155E7F4A103330D4E805

This is the account obtained by our spy: 0x38ec138a0ca16460d9993bde56ddd5234d5b851de391f46f63180d90194283e2
You have 10.17 ether as a budget for this operation.
Good Luck.
