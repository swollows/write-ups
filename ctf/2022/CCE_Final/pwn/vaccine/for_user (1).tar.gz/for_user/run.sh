#!/bin/sh
timeout --signal SIGKILL 60 python3 ./server.py
