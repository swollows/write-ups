https://github.com/Cisco-Talos/clamav

commit: 55b2eafc847caac68581ee691b575e9755d5dc68

