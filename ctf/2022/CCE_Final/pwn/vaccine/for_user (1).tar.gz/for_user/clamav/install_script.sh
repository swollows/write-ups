#!/bin/sh


apt-get update && apt-get install -y   `# install tools`   gcc make pkg-config python3 python3-pip python3-pytest valgrind   `# install clamav dependencies`   check libbz2-dev libcurl4-openssl-dev libjson-c-dev libmilter-dev   libncurses5-dev libpcre2-dev libssl-dev libxml2-dev zlib1g-dev cargo rustc -y
python3 -m pip install cmake
mkdir -p "./build" && cd "./build" && \
cmake .. \
      -DCMAKE_C_FLAGS="-no-pie" \ 
      -DCMAKE_BUILD_TYPE="Release" \
      -DCMAKE_INSTALL_PREFIX="/usr" \
      -DCMAKE_INSTALL_LIBDIR="/usr/lib" \
      -DAPP_CONFIG_DIRECTORY="/etc/clamav" \
      -DDATABASE_DIRECTORY="/var/lib/clamav" \
      -DENABLE_CLAMONACC=OFF \
      -DENABLE_EXAMPLES=OFF \
      -DENABLE_JSON_SHARED=ON \
      -DENABLE_MAN_PAGES=OFF \
      -DENABLE_MILTER=ON \
      -DENABLE_STATIC_LIB=OFF && \
make -j$(($(nproc) - 1)) install

CMD tail -f /dev/null
