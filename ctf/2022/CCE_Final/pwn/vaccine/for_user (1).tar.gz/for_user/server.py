#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os, sys
import random, tempfile

if __name__ == "__main__":
    print("sample html end with <EOF>)")

    sample_code = ""
    while "<EOF>" not in sample_code:
        sample_code += sys.stdin.read(1)

    sample_code = sample_code.split("<EOF>")[0]
    if len(sample_code) > 1024 * 1024 * 1024 * 10:
        print("too big")
        exit(0)

    sample = tempfile.NamedTemporaryFile()
    sample.write(bytes(sample_code, 'utf8'))
    sample.flush()

    filelist = tempfile.NamedTemporaryFile()
    filelist.write(bytes(sample.name, 'utf8') + b'\n')
    filelist.flush()

    fd = os.popen("/usr/bin/clamscan --file-list=" + filelist.name)
    print(fd.read())
    filelist.close()
    sample.close()
