#!/bin/bash
cd /usr/src/app
python3 bot.py
