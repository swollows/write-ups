<?php
	$dbcon = mysqli_connect("db", "redcorona", "redcorona111!", "redcorona");
?>