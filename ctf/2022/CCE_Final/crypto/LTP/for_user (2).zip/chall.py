#!/usr/bin/python3

from Crypto.Util.number import *
import string, random, signal
from hashlib import sha256

def alarm_handler(signum, frame):
    print('Timeout!')
    exit()

class LongTimePad:
    def __init__(self, bitLength, keyCount):
        self.keyCount = keyCount
        self.dbCount = keyCount
        self.bitLength = bitLength
        self.prime = getPrime(bitLength + 1)
        self.db = []
        self.key = []
        self.magic = 2
        self.basis = [-1,1]
        self.genKey()
        self.genDB()

    def genKey(self):
        for _ in range(self.keyCount):
            x = random.getrandbits(self.bitLength)
            self.key.append(x)

    def genDB(self):
        for _ in range(self.dbCount):
            self.db.append(self.basis[random.getrandbits(1)])

    def next(self):
        self.db = self.db[1:]
        self.db.append(self.basis[random.getrandbits(1)])

    def getLTP(self):
        s = 0
        for i in range(self.keyCount):
            x = self.key[i] * self.db[i]
            s = (s + x) % self.prime
        self.next()
        return s
    
    def magicFunc(self,inp):
        if self.magic == 0:
            return -1
        self.magic = self.magic - 1        
        db = []
        n = inp
        for _ in range(self.keyCount):
            db.append(self.basis[n & 1])
            n = n // 2
        s = 0
        for i in range(self.keyCount):
            x = (self.key[i] * db[i]) % self.prime
            s = (s + x) % self.prime
        return s

def getInput(str):
    inp = input(str)
    try:
        res = int(inp)
        return res
    except:
        return 0

def menu():
    print()
    print("** Long Time Pad **")
    print("1. get Prime")
    print("2. get LTP")
    print("3. get FLAG")
    print("4. BYE")
    print()


def pow():
    print("Solve PoW plz")
    s = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(16))
    print(s)
    answer = input()
    hash = bytes_to_long(sha256((s + answer).encode()).digest())
    if hash != (hash >> 24) << 24:
        exit() 

    


if __name__ == "__main__":
    pow()
    bitLen = 1024
    prime = getPrime(bitLen)
    print("Generating LTP...")
    signal.signal(signal.SIGALRM, alarm_handler)
    signal.alarm(300)
    LTP = LongTimePad(bitLen, 90)
    oracle = 512
    while(oracle):
        oracle = oracle - 1
        menu()
        n = getInput("input : ")
        if n == 1:
            print(f"Here is the prime : {prime}")

        elif n == 2:
            ltp = LTP.getLTP()
            print(f"Here is the LTP number : {ltp}")

        elif n == 3:
            print("If you can guess the LTPs, then you can get the FLAG!!")
            print("Do your best~")
            for round in range(1,101):
                guess = getInput(f"Round {round} : ")
                ltp = LTP.getLTP()
                if guess != ltp:
                    print("Sorry, it's wrong. BYE~")
                    exit()
            with open('/flag','r') as f:
                FLAG = f.read()
            print(f"HOORAY~~ Here is the FLAG : {FLAG}")
            exit()

        elif n == 4:
            print("Bye ~")
            exit()

        elif n == 0x1337:
            inp = getInput("plz give me the data : ")
            res = LTP.magicFunc(inp)
            print(f"Here is the result : {res}")

        else:
            print("Not valid input")

    print("I think you tried enough. BYE~")
    exit()
