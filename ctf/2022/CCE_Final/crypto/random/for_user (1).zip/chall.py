#!/usr/bin/python3

from Crypto.Util.number import *
import string, random, signal
from hashlib import sha256
def alarm_handler(signum, frame):
    print('Timeout!')
    exit()

class PRNG:
    def __init__(self, prime, secret, salt, maxLen):
        self.p = prime
        self.len = self.p.bit_length()
        self.xs = salt
        self.secret = secret
        self.maxLen = maxLen
        if self.maxLen > self.len:
            self.maxLen = self.len       

    def getrandbits(self, bits):
        if bits > self.maxLen:
            bits = self.maxLen
        x = self.xs[0]
        self.xs = self.xs[1:]
        num = inverse(x + self.secret, self.p) 
        return (num >> (self.len - bits))

    def viewData(self):
        return self.xs[0], len(self.xs)


def pow():
    print("Solve PoW plz")
    s = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(16))
    print(s)
    answer = input()
    hash = bytes_to_long(sha256((s + answer).encode()).digest())
    if hash != (hash >> 24) << 24:
        exit() 

def menu():
        print("1. Get Params")
        print("2. View Current Salt")
        print("3. getRandom Number")
        print("4. only for Admin")

def getInput(st):
    get = input(st)
    try:
        get = int(get)
    except:
        get = 0
    return get

if __name__ == "__main__":
    pow()
    signal.signal(signal.SIGALRM, alarm_handler)
    signal.alarm(60)
    bits = 512
    p = getPrime(bits)

    secret = getRandomRange(1 << (bits - 1), 1 << bits)
    assert secret.bit_length() == bits  

    salt = []
    for _ in range(50):
        salt.append(getRandomRange(1 << (bits - 1), 1 << bits) % p)

    prng = PRNG(p, secret, salt, 350)
    CHANCE = 30

    while(CHANCE):
        CHANCE = CHANCE - 1
        menu()
        get = getInput('Option > ')
        
        if get == 1:
            print(f'p : {prng.p}')
        
        elif get == 2:
            data, dataLen = prng.viewData()
            print(f'data : {data}')
            print(f'len : {dataLen}')
        
        elif get == 3:
            bit = getInput('bits > ')
            rand = prng.getrandbits(bit)
            print(f'random num : {rand}')
        
        elif get == 4:
            pw = getInput("Admin Password > ")
            if pw == secret:
                with open('/flag') as f:
                    flag = f.read()
                print(flag)
            print("BYE")
            exit()

        else:
            print("Invalid input")