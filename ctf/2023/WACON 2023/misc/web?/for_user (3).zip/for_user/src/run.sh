#!/bin/bash
node --experimental-permission --allow-fs-read=/app/* --allow-child-process /app/main.js