function download() {
    window.open(document.getElementById("download").href);
}