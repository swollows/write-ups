<?php
	if(!defined('__MAIN__')) exit('!^_^!');

	include(__TEMPLATE__ . 'head.php');

?>
	<main role="main" class="container">
		<div class="jumbotron">
			<h1>WACON CMS</h1>
			<p class="lead">WACON CMS</p>
		</div>
	</main>
<?php
	include(__TEMPLATE__ . 'tail.php');
?>

