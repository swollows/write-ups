window.addEventListener('DOMContentLoaded', function(){
    document.getElementById("write").addEventListener("click",function () {
        location.href='./note.php?p=write';
    } ,false);
})