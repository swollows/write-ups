<?php
	if(!defined('__MAIN__')) exit('!^_^!');
?>
	</body>
</html>
