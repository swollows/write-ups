window.addEventListener('DOMContentLoaded', function(){
    document.getElementById("write").addEventListener("click",function () {
        location.href='./board.php?p=write';
    } ,false);
})
