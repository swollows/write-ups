#!/bin/bash
docker build . -t dreambank/kings-cross
