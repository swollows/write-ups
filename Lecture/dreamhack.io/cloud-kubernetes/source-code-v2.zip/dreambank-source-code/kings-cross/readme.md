# King's Cross (User-service)

## Features

- /register : register (pre-auth)
- /login : longin (pre-auth)
    - return auth token (JWT)	
- /reset-password : reset password (pre-auth)
- /reset-password-check : reset password-check (pre-auth, with password_reset_token)
