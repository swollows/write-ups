import random
from uuid import uuid4

from django.conf import settings
from django.contrib.auth import authenticate, get_user_model

from rest_framework.exceptions import ValidationError
from rest_framework import serializers
from django.contrib.auth.models import User, Group
from rest_framework.validators import UniqueValidator
from django.contrib.auth.password_validation import validate_password

from django.core.cache import cache

from .utils import TokenManager


class RegisterSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(
        required=True, validators=[UniqueValidator(queryset=User.objects.all())]
    )

    password = serializers.CharField(
        write_only=True, required=True, validators=[validate_password]
    )
    password_confirm = serializers.CharField(write_only=True, required=True)
    first_name = serializers.CharField(required=True)
    last_name = serializers.CharField(required=True)

    class Meta:
        model = User
        fields = ("email", "password", "password_confirm", "first_name", "last_name")

    def validate(self, attrs):
        if attrs["password"] != attrs["password_confirm"]:
            raise serializers.ValidationError(
                {"password": "Password fields didn't match."}
            )

        attrs["random_user_name"] = str(uuid4())

        return attrs

    def create(self, validated_data):
        user = User.objects.create(
            username=validated_data["random_user_name"],
            email=validated_data["email"],
            first_name=validated_data["first_name"],
            last_name=validated_data["last_name"],
        )
        user.groups.add(Group.objects.get(name="NORMAL_USER"))

        user.set_password(validated_data["password"])
        user.save()

        return user


class LoginSerializer(serializers.Serializer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields["email"] = serializers.EmailField(required=True)
        self.fields["password"] = serializers.CharField(required=True)

    def validate(self, attrs):
        try:
            username = User.objects.get(email=attrs["email"]).username
        except:
            raise ValidationError({"email": "Email not found."})

        authenticate_kwargs = {
            "username": username,
            "password": attrs["password"],
        }

        try:
            authenticate_kwargs["request"] = self.context["request"]
        except KeyError:
            raise KeyError("Unkown Error")

        self.user = authenticate(**authenticate_kwargs)
        if self.user is None:
            raise ValidationError({"password": "Password not matched"})

        t = TokenManager(settings.JWT_SECRET)

        return {"token": t.generate_token(self.user)}


class ResetPasswordSerializer(serializers.Serializer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields["email"] = serializers.EmailField(required=True)

    def validate(self, attrs):
        user = User.objects.get(email=attrs["email"])  # can raise NotFound Error
        attrs["pin"] = str(random.randrange(1, 10000)).rjust(4, "0")
        attrs["password_reset_token"] = str(uuid4())
        # TODO: send an email with pin code to user
        return attrs

    def save(self):
        pin = self.validated_data["pin"]
        password_reset_token = self.validated_data["password_reset_token"]
        cache.set(password_reset_token, pin, timeout=180)


class ResetPasswordTokenCheckSerializer(serializers.Serializer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields["email"] = serializers.EmailField(required=True)
        self.fields["password_reset_token"] = serializers.CharField(required=True)
        self.fields["pin"] = serializers.IntegerField(required=True)
        self.fields["password"] = serializers.CharField(
            required=True, validators=[validate_password]
        )

    def validate(self, attrs):
        password_reset_token = attrs["password_reset_token"]
        pin = cache.get(password_reset_token)
        if pin is None:
            raise ValidationError(
                {"password_reset_token": "Password reset token does not exists"}
            )
        self.user = User.objects.get(email=attrs["email"])  # can raise NotFound Error

        if int(pin) != attrs["pin"]:
            raise ValidationError({"pin": "Invalid pin"})

        return attrs

    def save(self):
        self.user.set_password(self.validated_data["password"])
        self.user.save()
