import jwt
import time
import base64


class TokenManager(object):
    secret_key = None
    # INVALID = jwt.asdasdasd # TODO meu made this

    def __init__(self, secret_key=""):
        if secret_key == "":
            secret_key = base64.b64decode("ueoU/gXIa3tvtRI2a71lSfO5nU1+/4p2")

        self.secret_key = secret_key

    def generate_token(self, user):
        data = dict()
        data["emailAddress"] = user.email
        data["sub"] = str(user.pk)
        data["group"] = str(user.groups.all()[0])
        data["iss"] = ("issuer1",)
        data["exp"] = int(time.time()) + 3600
        data["iat"] = int(time.time())

        token = jwt.encode(data, self.secret_key, algorithm="HS256")
        return token

    def verify_token(self, token):
        """
        except jwt.exceptions.InvalidSignatureError:
        except jwt.exceptions.DecodeError:
        """
        return jwt.decode(token, self.secret_key, algorithm="HS256")
