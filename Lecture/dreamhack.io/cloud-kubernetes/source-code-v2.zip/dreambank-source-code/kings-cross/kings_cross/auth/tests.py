import json
from django.test import TestCase
from rest_framework.test import APIRequestFactory

from auth.views import (
    ResetPasswordView,
    ResetPasswordTokenCheckView,
)

from django.core.cache import cache
from django.contrib.auth.models import User, Group


# Create your tests here.
class PasswordResetTest(TestCase):
    victim_email = "victim@victim.com"
    valid_email = "valid@valid.com"

    def setUp(self):
        self.factory = APIRequestFactory()
        self.reset_password_view = ResetPasswordView.as_view()
        self.reset_password_check_view = ResetPasswordTokenCheckView.as_view()
        PasswordResetTest.init_groups()
        PasswordResetTest.register_users()

    def init_groups():
        GROUP_NAMES = ["NORMAL_USER", "CS", "ADMIN"]
        for g in GROUP_NAMES:
            _ = Group(name=g)
            try:
                _.save()
            except:
                print(f"{g} has been already added")

    def register_users():
        victim = User.objects.create(
            username="test1", email="victim@victim.com", first_name="a", last_name="b"
        )
        victim.groups.add(Group.objects.get(name="NORMAL_USER"))
        victim.set_password("asdf1234asdf1234")
        victim.save()

        valid = User.objects.create(
            username="test2", email="valid@valid.com", first_name="a", last_name="b"
        )
        valid.groups.add(Group.objects.get(name="NORMAL_USER"))
        valid.set_password("asdf1234asdf1234")
        valid.save()

    def test_password_reset_with_different_email(self):
        # Step 1
        req = self.factory.post(
            "reset-password/", {"email": self.valid_email}, format="json"
        )
        res = self.reset_password_view(req)
        res.render()
        data = json.loads(res.content)
        password_reset_token = data["data"]["password_reset_token"]

        # Step 2
        data = cache.get(f"PASSWORD_RESET_TOKEN:{password_reset_token}")

        # Step 3
        req = self.factory.post(
            "reset-password-check/",
            {
                "email": self.victim_email,
                "pin": data["pin"],
                "password_reset_token": password_reset_token,
                "password": "holymolyasdf",
            },
            format="json",
        )

        res = self.reset_password_check_view(req)
        res.render()
        self.assertEqual(
            res.content,
            b'{"success":false,"message":"Password Reset Check Failed","data":{"email":["Email does not match with the email in password_reset_token."]}}',
        )

    def test_pin_leakage(self):
        req = self.factory.post(
            "reset-password/", {"email": self.valid_email}, format="json"
        )
        res = self.reset_password_view(req)
        res.render()
        data = json.loads(res.content)
        with self.assertRaises(KeyError):
            data["data"]["pin"]

    def test_password_reset_rate_limit(self):
        # rate limiting check
        # Step 1
        req = self.factory.post(
            "reset-password/", {"email": self.victim_email}, format="json"
        )
        res = self.reset_password_view(req)
        res.render()
        data = json.loads(res.content)
        password_reset_token = data["data"]["password_reset_token"]

        # Step 2
        with self.assertRaises(KeyError):
            for i in range(5):  # rate limit reached.
                req = self.factory.post(
                    "reset-password-check/",
                    {
                        "email": self.victim_email,
                        "pin": "123412341234",
                        "password_reset_token": password_reset_token,
                        "password": "holymolyasdf",
                    },
                    format="json",
                )

                res = self.reset_password_check_view(req)
                res.render()
                json.loads(res.content)["data"]["pin"]
