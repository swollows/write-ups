from json import dumps
from django.contrib.auth.models import User

from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.exceptions import ValidationError

from .serializer import (
    RegisterSerializer,
    LoginSerializer,
    ResetPasswordSerializer,
    ResetPasswordTokenCheckSerializer,
)


class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer

    def create(self, request, *args, **kwargs):
        try:
            return super(generics.CreateAPIView, self).create(request, *args, **kwargs)
        except ValidationError as e:
            return Response(
                {"success": False, "message": "Register Failed", "data": e.detail},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class LoginView(generics.GenericAPIView):
    serializer_class = LoginSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        try:
            serializer.is_valid(raise_exception=True)
        except KeyError as e:
            return Response(
                {"success": False, "message": "Login Failed, Unkown error occured!"},
                status=status.HTTP_404_NOT_FOUND,
            )
        except ValidationError as e:
            return Response(
                {"success": False, "message": "Login Failed", "data": e.detail},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        return Response(
            {"success": True, "data": serializer.validated_data},
            status=status.HTTP_200_OK,
            headers={
                "Set-Cookie": f"Authorization={serializer.validated_data['token']}; HttpOnly; Path=/;"
            },
        )


class ResetPasswordView(generics.GenericAPIView):
    serializer_class = ResetPasswordSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)

        try:
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response(
                {"success": True, "data": serializer.validated_data},
                status=status.HTTP_200_OK,
            )
        except Exception as e:
            return Response(
                {"success": False, "message": "Pasword Reset Generation Failed"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class ResetPasswordTokenCheckView(generics.GenericAPIView):
    serializer_class = ResetPasswordTokenCheckSerializer

    def post(self, request, *args, **kwargs):
        self.serializer_class = ResetPasswordTokenCheckSerializer
        serializer = self.get_serializer(data=request.data)

        try:
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response({"success": True, "data": {}}, status=status.HTTP_200_OK)
        except ValidationError as e:
            print(e)
            return Response(
                {
                    "success": False,
                    "message": "Password Reset Check Failed",
                    "data": e.detail,
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
