from django.contrib import admin
from django.urls import path, include

from rest_framework import serializers, viewsets, routers, generics, status
from rest_framework.response import Response

from auth.views import (
    RegisterView,
    LoginView,
    ResetPasswordView,
    ResetPasswordTokenCheckView,
)


router = routers.DefaultRouter()

urlpatterns = [
    path("", include(router.urls)),
    path("register/", RegisterView.as_view(), name="register"),
    path("login/", LoginView.as_view(), name="login"),
    path("reset-password/", ResetPasswordView.as_view(), name="reset-password"),
    path(
        "reset-password-check/",
        ResetPasswordTokenCheckView.as_view(),
        name="reset-password-check",
    ),
    path("api-auth/", include("rest_framework.urls", namespace="rest_framework")),
    path("admin/", admin.site.urls),
]
