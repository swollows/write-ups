SECRET_KEY = "44)iz6jpw3ls%aymczof$*i+-q8hc5-g%!-n96h-971j6h!2r#"
DEBUG = True
ALLOWED_HOSTS = ["*"]


SQLITE_DB = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": "dev.db",
    }
}

DATABASES = SQLITE_DB

# Cache
CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.filebased.FileBasedCache",
        "LOCATION": "./caches_dev/",
    }
}

JWT_SECRET = b"example jwt secret"
