import os

from .base import *

DEPLOY_ENV_KEY = "DEPLOY_ENV"
DEPLOY_ENV = os.environ[DEPLOY_ENV_KEY] if DEPLOY_ENV_KEY in os.environ else "dev"

if DEPLOY_ENV == "dev":
    from .dev import *
elif DEPLOY_ENV == "prod":
    from .prod import *
