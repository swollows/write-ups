SECRET_KEY = "44)iz6jpw3ls%aymczof$*i+-q8hc5-g%!-n96h-971j6h!2r#"
DEBUG = True
ALLOWED_HOSTS = ["*"]

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "NAME": "dreambank",
        "USER": "root",
        "PASSWORD": "password",
        "HOST": "mysql",
        "PORT": 3306,
    }
}

# Cache
CACHES = {
    "default": {
        "BACKEND": "django_redis.cache.RedisCache",
        "LOCATION": "redis://redis:6379/0",
        "OPTIONS": {
            "CLIENT_CLASS": "django_redis.client.DefaultClient",
        },
    }
}

JWT_SECRET = open("/etc/keyfile", "rb").read().strip()
