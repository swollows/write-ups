from django.contrib.auth.models import Group

GROUP_NAMES = ["NORMAL_USER", "CS", "ADMIN"]
for g in GROUP_NAMES:
    _ = Group(name=g)
    try:
        _.save()
    except:
        print(f"{g} has been already added")
