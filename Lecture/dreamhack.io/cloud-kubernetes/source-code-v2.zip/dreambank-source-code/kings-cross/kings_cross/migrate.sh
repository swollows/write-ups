#!/bin/bash
python manage.py migrate
python manage.py shell < scripts/make_default_groups.py

