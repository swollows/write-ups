const express = require('express');
var conn = require('../db/pool');
var router = express.Router();


/* GET board listing. */
router.get('/', async function(req, res, next) {
  try{
    var { type, keyword }  = req.query;
    var condition = "";
    if (type || keyword){
      condition = "WHERE 1 ";
      if(type){
        condition += "AND board_type='"+type+"'";
      }
      if(keyword){
        condition += "AND title like '%"+keyword+"%' OR content like '%"+keyword+"%'";
      }
    }  
    const [rows] = await conn.execute("SELECT * FROM board " + condition + " ORDER BY date DESC");
    if (!type) type = 'All'
    res.render('index', { rows: rows, type: type });
  }catch(err){
    return next(err);
  }
});

/* GET view article. */
router.get('/view/:id', async function(req, res, next) {
  try{
    const { id } = req.params;  
    if(!parseInt(id, 10)){
      return next();
    }
  
    const [rows] = await conn.execute("SELECT * FROM board where id=" + id);
    if(rows.length == 0){
      return res.send('Not Found !', 404);
    }
    var owner = false;
    if(req.user_email === rows[0].writer){
      owner = true;
    }
    if(rows[0].private && !owner){ 
      return res.status(401).render('unauthorized')
    }
    var file = null;
    if(rows[0].files){
      [file] = await conn.execute("SELECT * FROM files where id="+rows[0].files);
      file = file[0]; // row
    }
    res.render('view', { row: rows[0], file: file, owner: owner });
    next();
  }catch(err){
    return next(err);
  }
});

/* GET write form. */
router.get('/write', function(req, res, next) {
  if(!req.user_id && !req.user_email){
    res.redirect('/login')
    return next()
  }
  res.render('write');
});

/* POST write */
router.post('/write', async function(req, res, next) {
  try{
    const { title, content, private }  = req.body;
    if(!req.user_id && !req.user_email){
      return res.redirect('/login')
    }
    var fileId = null;
    if(req.files){
      const file = req.files.file;
      const uploadPath = process.cwd() + '/uploads/' + file.md5;
      
      // File Upload
      file.mv(uploadPath, function(err) {
        if (err) return next(err);
      });

      // DB Insert
      const [fileResult] = await conn.execute("INSERT INTO files(filename, filepath) VALUES(?, ?)",[file.name, uploadPath]);
      fileId = fileResult.insertId;
    }
    var board_type = "free";
    var writer = req.user_email;
    await conn.execute("INSERT INTO board(title, content, writer, private, date, board_type, files) VALUES(?, ?, ?, ?, ?, ?, ?)",[title, content, writer, private?true:false, new Date(), board_type, fileId]);
    return res.redirect(req.baseUrl);
  }catch(err){
    return next(err);
  }
});

/* GET modify article. */
router.get('/modify/:id', async function(req, res, next) {
  try{
    const { id } = req.params;  
    if(!parseInt(id, 10)){
      return next();
    }
  
    const [rows] = await conn.execute("SELECT * FROM board where id=" + id);
    var file = null;
    if(rows[0].files){
      [file] = await conn.execute("SELECT * FROM files where id="+rows[0].files);
      file = file[0]; // row
    }
    res.render('modify', { row: rows[0], file: file });
  }catch(err){
    return next(err);
  }
});

/* POST modify article. */
router.post('/modify/:id', async function(req, res, next) {
  try{
    const { id } = req.params;  
    if(!parseInt(id, 10)){
      return next();
    }
    const { title, content, private }  = req.body;
    var fileId = null;
    if(req.files){
      const file = req.files.file;
      const uploadPath = process.cwd() + '/uploads/' + file.md5;
      
      // File Upload
      file.mv(uploadPath, function(err) {
        if (err) return next(err);
      });

      // DB Insert
      const [fileResult] = await conn.execute("INSERT INTO files(filename, filepath) VALUES(?, ?)",[file.name, uploadPath]);
      fileId = fileResult.insertId;
    }else{
      const [rows] = await conn.execute("SELECT * FROM board where id=" + id);
      if(rows[0].files){
        fileId = rows[0].files;
      }
    }
    // DB Update
    await conn.execute("UPDATE board SET title=?, content=?, private=?, date=?, files=? WHERE id=?",[title, content, private?true:false, new Date(), fileId, id]);
    return res.redirect(req.baseUrl);
  }catch(err){
    return next(err);
  }
});

/* DELETE article. */
router.delete('/delete/:id', async function(req, res, next) {
  try{
    const { id } = req.params;  
    if(!parseInt(id, 10)){
      return next();
    }
    if(!req.user_id && !req.user_email){
      return res.redirect('/login')
    }
    const [rows] = await conn.execute("SELECT * FROM board where id=" + id);
    if(rows[0]){
      if(req.user_email !== rows[0].writer){
        return res.status(401).render('unauthorized')
      }
      await conn.execute("DELETE FROM board where id=" + id);
    }else{
      return res.send('Not Found !', 404);
    }
    res.send('OK');
  }catch(err){
    return next(err);
  }
});

/* GET file. */
router.get('/download', async function(req, res, next) {
  try{
    const { filepath, filename } = req.query;
    if(filepath && filename){
      res.download(filepath, filename);
    }else{
      res.send('Not Found !');
    }
  }catch(err){
    return next(err);
  }
});

module.exports = router;
