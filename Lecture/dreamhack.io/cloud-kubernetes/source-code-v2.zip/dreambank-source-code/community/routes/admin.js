var express = require('express');
var conn = require('../db/pool');
var router = express.Router();

/* GET Q&A List page. */
router.get('/', async function(req, res, next) {
  try{
    var [rows] = await conn.execute("SELECT * FROM qna ORDER BY date DESC");
    res.render('admin_qna', {rows: rows});
  }catch(err){
    return next(err);
  }
});

/* GET Q&A answer page. */
router.get('/answer/:id', async function(req, res, next) {
  try{
    const { id } = req.params;  
    if(!parseInt(id, 10)){
      return next();
    }

    var [rows] = await conn.execute("SELECT * FROM qna where id=?", [id]);
    res.render('admin_qna_answer', {row: rows[0]});
  }catch(err){
    return next(err);
  }
});

/* POST Q&A answer. */
router.post('/answer/:id', async function(req, res, next) {
  try{
    const { id } = req.params;  
    if(!parseInt(id, 10)){
      return next();
    }

    const { answer }  = req.body;
    await conn.execute("UPDATE qna SET answer=? WHERE id=?",[answer, id]);
    res.redirect(req.baseUrl);
  }catch(err){
    return next(err);
  }
});

/* GET Notice write page. */
router.get('/notice', async function(req, res, next) {
  res.render('admin_notice');
  next();
});

/* POST Notice write. */
router.post('/notice', async function(req, res, next) {
  try{
    const { title, content }  = req.body;
    var fileId = null;
    if(req.files){
      const file = req.files.file;
      const uploadPath = process.cwd() + '/uploads/' + file.md5;
      
      // File Upload
      file.mv(uploadPath, function(err) {
        if (err) return next(err);
      });

      // DB Insert
      const [fileResult] = await conn.execute("INSERT INTO files(filename, filepath) VALUES(?, ?)",[file.name, uploadPath]);
      fileId = fileResult.insertId;
    }
    var board_type = "notice";
    var writer = req.user_email;
    await conn.execute("INSERT INTO board(title, content, writer, date, board_type, files) VALUES(?, ?, ?, ?, ?, ?)",[title, content, writer, new Date(), board_type, fileId]);
    return res.redirect(req.baseUrl);
  }catch(err){
    return next(err);
  }
});

module.exports = router;
