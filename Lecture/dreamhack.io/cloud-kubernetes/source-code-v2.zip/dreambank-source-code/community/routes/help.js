var express = require('express');
var conn = require('../db/pool');
var router = express.Router();

/* GET FAQ page. */
router.get('/', function(req, res, next) {
  res.render('help');
  next();
});

/* GET Q&A page. */
router.get('/qna', async function(req, res, next) {
  try{
    if(!req.user_id && !req.user_email){
      return res.redirect('/login')
    }
    var [rows] = await conn.execute("SELECT * FROM qna where writer=? ORDER BY date DESC", [req.user_email]);
    res.render('qna_list', {rows: rows});
  }catch(err){
    return next(err);
  }
});

/* GET Q&A page. */
router.get('/qna/view/:id', async function(req, res, next) {
  try{
    if(!req.user_id && !req.user_email){
      return res.redirect('/login')
    }

    const { id } = req.params;  
    if(!parseInt(id, 10)){
      return next();
    }

    var [rows] = await conn.execute("SELECT * FROM qna where id=?", [id]);
    var owner = false;
    if(req.user_email === rows[0].writer){
      owner = true;
    }
    if(!owner){ 
      return res.status(401).render('unauthorized')
    }
    res.render('qna_view', {row: rows[0]});
  }catch(err){
    return next(err);
  }
});

/* GET Q&A write page. */
router.get('/qna/write', function(req, res, next) {
  if(!req.user_id && !req.user_email){
    return res.redirect('/login')
  }
  res.render('qna_write');
  next();
});

/* POST Q&A write. */
router.post('/qna/write', async function(req, res, next) {
  try{
    if(!req.user_id && !req.user_email){
      return res.redirect('/login')
    }
    const { title, content }  = req.body;
    var writer = req.user_email;
    await conn.execute("INSERT INTO qna(title, content, writer, date) VALUES(?, ?, ?, ?)",[title, content, writer, new Date()]);
    res.redirect(req.baseUrl+'/qna');
  }catch(err){
    return next(err);
  }
});

module.exports = router;
