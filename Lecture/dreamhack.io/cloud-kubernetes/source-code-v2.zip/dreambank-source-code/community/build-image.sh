#!/bin/bash
docker build . -t dreambank/community
