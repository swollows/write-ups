var createError = require('http-errors');

const USERID = "x-userid";
const USEREMAIL = "x-email";
const USERGROUP = "x-group";

function userHandler(req, res, next) {
  req.user_id = req.header(USERID);
  req.user_email = req.header(USEREMAIL);
  res.locals.user_email = req.header(USEREMAIL);
  res.locals.user_group = req.header(USERGROUP)
  next();
}

function adminHandler(req, res, next) {
  req.user_group = req.header(USERGROUP);
  // check admin
  if( ['CS', 'ADMIN'].includes(req.user_group) ){
    return next();
  }
  return next(createError(404));
}

module.exports = { userHandler, adminHandler };