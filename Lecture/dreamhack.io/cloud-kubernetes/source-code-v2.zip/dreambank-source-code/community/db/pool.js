const mysql = require("mysql2/promise");
const dbConfig = require('../config/db.config.js');

const conn = mysql.createPool({
  host: dbConfig.HOST,
  user: dbConfig.USER,
  port: dbConfig.PORT || 3306,
  password: dbConfig.PASSWORD,
  database: dbConfig.DB,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

module.exports = conn;
