USE dreambank;

CREATE TABLE IF NOT EXISTS `board`
(
   `id`         INTEGER auto_increment,
   `title`      VARCHAR(255) NOT NULL,
   `content`    VARCHAR(255),
   `writer`     VARCHAR(255) NOT NULL,
   `private`    TINYINT(1) DEFAULT false,
   `date`       DATETIME,
   `board_type` VARCHAR(255) NOT NULL,
   `files`      INTEGER,
   PRIMARY KEY (`id`)
)DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

CREATE TABLE IF NOT EXISTS `qna`
(
    `id`        INTEGER auto_increment,
    `title`     VARCHAR(255) NOT NULL,
    `content`   VARCHAR(255) NOT NULL,
    `writer`    VARCHAR(255) NOT NULL,
    `date`      DATETIME,
    `answer`    VARCHAR(255),
    PRIMARY KEY (`id`)
)DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;

CREATE TABLE IF NOT EXISTS `files`
(
   `id`        INTEGER auto_increment,
   `filename`  VARCHAR(255) NOT NULL,
   `filepath`  VARCHAR(255) NOT NULL,
   PRIMARY KEY (`id`)
)DEFAULT CHARSET=utf8 COLLATE utf8_general_ci;
