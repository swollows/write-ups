module.exports = {
    HOST: process.env.MYSQLHOST || "localhost",
    USER: process.env.MYSQLUSER || "root",
    PASSWORD: process.env.MYSQLPASSWORD || "password",
    DB: process.env.MYSQLDB || "dreambank",
    PORT: process.env.MYSQLPORT || 3306
};
