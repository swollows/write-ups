#!/bin/bash
docker build . -t dreambank/hello-world
