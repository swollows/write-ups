import os

DEPLOY_ENV = None

if "DEPLOY_ENV" in os.environ:
    DEPLOY_ENV = os.environ["DEPLOY_ENV"]
else:
    DEPLOY_ENV = "dev"
