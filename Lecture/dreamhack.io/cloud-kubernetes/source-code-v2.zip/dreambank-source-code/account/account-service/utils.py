import falcon


def make_return_message(status: bool, message: str = "", data: dict = {}):
    return dict(success=status, message=message, data=data)


def max_body(limit):
    async def hook(req, resp, resource, params):
        length = req.content_length
        if length is not None and length > limit:
            msg = (
                "The size of the request is too large. The body must not "
                "exceed " + str(limit) + " bytes in length."
            )

            raise falcon.HTTPPayloadTooLarge(
                title="Request body is too large", description=msg
            )

    return hook
