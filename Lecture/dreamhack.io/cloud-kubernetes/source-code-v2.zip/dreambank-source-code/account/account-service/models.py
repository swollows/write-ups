import datetime
from sqlalchemy import ForeignKey, or_
from sqlalchemy.orm import declarative_base, relationship

from db import engine, Session
from settings import DEPLOY_ENV

Base = declarative_base()

from sqlalchemy import Column, Integer, String, DateTime


class AuthUserWrapper(Base):
    __tablename__ = "auth_user"
    id = Column(Integer, primary_key=True, unique=True)
    email = Column(String(200))
    first_name = Column(String(200))
    last_name = Column(String(200))

    def __repr__(self):
        return f"<AuthUserWrapper(pk={self.id}, email='{self.email}', name='{self.last_name} {self.first_name}')>"


class Account(Base):
    __tablename__ = "accounts"

    id = Column(Integer, primary_key=True)
    number = Column(String(200), unique=True)  # 1234-1234-1234-1234
    nickname = Column(String(200))  # dream's account
    balance = Column(Integer)  # 1337

    owner_id = Column(Integer, ForeignKey("auth_user.id"), unique=True)
    owner = relationship("AuthUserWrapper")

    def __repr__(self):
        return f"<Account(pk={self.id}, number='{self.number}', nickname='{self.nickname}', balance='{self.balance}')>"

    def to_dict(self):
        return dict(
            id=self.id, number=self.number, nickname=self.nickname, balance=self.balance
        )


class TransferHistory(Base):
    __tablename__ = "transfer_histories"

    id = Column(Integer, primary_key=True)
    from_account_id = Column(Integer, ForeignKey("accounts.id"))
    from_account = relationship("Account", foreign_keys=[from_account_id])

    to_account_id = Column(Integer, ForeignKey("accounts.id"))
    to_account = relationship("Account", foreign_keys=[to_account_id])
    amount = Column(Integer)
    transfer_date = Column(DateTime, default=datetime.datetime.utcnow)

    def __repr__(self):
        return f"<TransferHistory(pk={self.id}, from='{self.from_account_id}', to='{self.to_account_id}', amount='{self.amount}', transfer_date'{self.transfer_date}')>"

    def to_dict(self):
        return dict(
            id=self.id,
            from_account=self.from_account.to_dict(),
            to_account=self.to_account.to_dict(),
            amount=self.amount,
            transfer_date=str(self.transfer_date),
        )


class FavoriteAccount(Base):
    __tablename__ = "favorite_accounts"

    id = Column(Integer, primary_key=True)
    account_id = Column(Integer, ForeignKey("accounts.id"))
    account = relationship("Account", foreign_keys=[account_id])

    owner_id = Column(Integer, ForeignKey("auth_user.id"))
    owner = relationship("AuthUserWrapper", foreign_keys=[owner_id])

    def __repr__(self):
        return f"<FavoriteAccount(pk={self.id}, owner_id='{self.owner_id}', account_id='{self.account_id}')>"

    def to_dict(self):
        return dict(
            id=self.id,
            account=self.account.to_dict(),
        )


if __name__ == "__main__":
    import sys

    try:
        if sys.argv[1] == "create":
            try:
                session = Session()
                session.execute("drop table accounts;")
                session.commit()
                session.execute("drop table transfer_histories;")
                session.commit()
                session.execute("drop table favorite_accounts;")
                session.commit()
                if DEPLOY_ENV == "local":
                    session.execute("drop table auth_user;")
                    session.commit()
            except:
                pass
            Base.metadata.create_all(engine, checkfirst=True)
            # set default account and data
            if DEPLOY_ENV == "local":
                s = Session()
                # Add user test
                a_user = AuthUserWrapper(
                    email="foo@test.com", first_name="foo", last_name="kim"
                )  # should change it..
                b_user = AuthUserWrapper(
                    email="bar@test.com", first_name="bar", last_name="kim"
                )  # should change it..
                s.add(a_user)
                s.add(b_user)
                s.commit()

                a_user = s.query(AuthUserWrapper).all()[0]
                b_user = s.query(AuthUserWrapper).all()[1]

                # Add account test
                a_account = Account(
                    number="1234-1234-1234-1234",
                    nickname="my account",
                    balance=1337,
                    owner_id=a_user.id,
                )
                b_account = Account(
                    number="1234-1234-1234-1235",
                    nickname="my account 22",
                    balance=1337,
                    owner_id=b_user.id,
                )
                s.add(a_account)
                s.add(b_account)
                s.commit()

                a_account = s.query(Account).get(a_user.id)
                b_account = s.query(Account).get(b_user.id)

                # Transfer money and save history test

                amount = 100
                a_account.balance += amount
                b_account.balance -= amount
                transfer_history = TransferHistory(
                    from_account_id=a_account.id,
                    to_account_id=b_account.id,
                    amount=amount,
                )
                s.add(a_account)
                s.add(b_account)
                s.add(transfer_history)
                s.commit()

                # Add favorite test
                favorite_account = FavoriteAccount(
                    account_id=b_account.id, owner_id=a_user.id
                )
                s.add(favorite_account)
                s.commit()

                # Final test
                u = s.query(AuthUserWrapper).get(a_user.id)
                account = s.query(Account).filter(Account.owner_id == u.id).one()
                histories = (
                    s.query(TransferHistory)
                    .filter(
                        or_(
                            TransferHistory.from_account_id == u.id,
                            TransferHistory.to_account_id == u.id,
                        )
                    )
                    .all()
                )
                favorites = (
                    s.query(FavoriteAccount)
                    .filter(FavoriteAccount.owner_id == u.id)
                    .all()
                )
                print("----------------------")
                print("User", u)
                print("Account", account)
                print("Histories", histories)
                print("Favorites", favorites)

    except Exception as e:
        import traceback

        traceback.print_exc()
