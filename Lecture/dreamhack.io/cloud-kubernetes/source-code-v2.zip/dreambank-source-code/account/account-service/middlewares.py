import random
import json
import logging
import uuid

import falcon
import falcon.asgi

# import httpx

from db import Session
from models import Account

from sqlalchemy import exc

from utils import make_return_message, max_body
import json

import falcon


class AuthMiddleware:
    async def process_request(self, req, resp):
        user_id = req.get_header("x-userid")

        if user_id is None:
            description = "Please provide an auth token " "as part of the request."

            raise falcon.HTTPUnauthorized(
                title="Auth token required",
                description=description,
                href="/login",
            )

        req.context.user_id = user_id


class RequireJSON:
    async def process_request(self, req, resp):
        if not req.client_accepts_json:
            raise falcon.HTTPNotAcceptable(
                description="This API only supports responses encoded as JSON.",
                href="http://docs.examples.com/api/json",
            )

        if req.method in ("POST", "PUT"):
            if "application/json" not in req.content_type:
                raise falcon.HTTPUnsupportedMediaType(
                    description="This API only supports requests encoded as JSON.",
                    href="http://docs.examples.com/api/json",
                )


class JSONTranslator:
    # NOTE: Normally you would simply use req.get_media() and resp.media for
    # this particular use case; this example serves only to illustrate
    # what is possible.

    async def process_request(self, req, resp):
        # NOTE: Test explicitly for 0, since this property could be None in
        # the case that the Content-Length header is missing (in which case we
        # can't know if there is a body without actually attempting to read
        # it from the request stream.)
        if req.content_length == 0 or req.method == "GET":
            # Nothing to do
            return

        body = await req.stream.read()
        if not body:
            raise falcon.HTTPBadRequest(
                title="Empty request body",
                description="A valid JSON document is required.",
            )

        try:
            req.context.doc = json.loads(body.decode("utf-8"))

        except (ValueError, UnicodeDecodeError):
            description = (
                "Could not decode the request body. The "
                "JSON was incorrect or not encoded as "
                "UTF-8."
            )

            raise falcon.HTTPBadRequest(title="Malformed JSON", description=description)

    async def process_response(self, req, resp, resource, req_succeeded):
        if not hasattr(resp.context, "result"):
            return

        resp.text = json.dumps(resp.context.result)


class DBSession:
    async def process_request(self, req, resp):
        req.context.session = Session()

    async def process_response(self, req, resp, resource, req_succeeded):
        req.context.session.close()
