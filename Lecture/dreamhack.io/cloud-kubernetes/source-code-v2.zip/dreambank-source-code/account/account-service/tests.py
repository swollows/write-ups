from falcon import testing
from sqlalchemy.orm import declarative_base
from sqlalchemy import or_

import settings

settings.DEPLOY_ENV = "test"

from models import Account, TransferHistory, FavoriteAccount, AuthUserWrapper, Base
from db import engine, Session
from main import app


class AccountTestCase(testing.TestCase):
    def setUp(self):
        super(AccountTestCase, self).setUp()
        self.app = app

        self.Session = Session

        session = self.Session()

        try:
            session = Session()
            session.execute("drop table accounts;")
            session.commit()
            session.execute("drop table transfer_histories;")
            session.commit()
            session.execute("drop table favorite_accounts;")
            session.commit()
            session.execute("drop table auth_user;")
            session.commit()
        except:
            pass

        Base.metadata.create_all(engine, checkfirst=True)
        # set default account and data
        s = Session()
        # Add user test
        a_user = AuthUserWrapper(
            email="foo@test.com", first_name="foo", last_name="kim"
        )  # should change it..
        b_user = AuthUserWrapper(
            email="bar@test.com", first_name="bar", last_name="kim"
        )  # should change it..
        s.add(a_user)
        s.add(b_user)
        s.commit()

        a_user = s.query(AuthUserWrapper).all()[0]
        b_user = s.query(AuthUserWrapper).all()[1]

        # Add account test
        a_account = Account(
            number="1234-1234-1234-1234",
            nickname="my account",
            balance=1337,
            owner_id=a_user.id,
        )
        b_account = Account(
            number="1234-1234-1234-1235",
            nickname="my account 22",
            balance=1337,
            owner_id=b_user.id,
        )
        s.add(a_account)
        s.add(b_account)
        s.commit()

        a_account = s.query(Account).get(a_user.id)
        b_account = s.query(Account).get(b_user.id)

        # Transfer money and save history test

        amount = 100
        a_account.balance += amount
        b_account.balance -= amount
        transfer_history = TransferHistory(
            from_account_id=a_account.id,
            to_account_id=b_account.id,
            amount=amount,
        )
        s.add(a_account)
        s.add(b_account)
        s.add(transfer_history)
        s.commit()

        # Add favorite test
        favorite_account = FavoriteAccount(account_id=b_account.id, owner_id=a_user.id)
        s.add(favorite_account)
        s.commit()

        # Final test
        u = s.query(AuthUserWrapper).get(a_user.id)
        account = s.query(Account).filter(Account.owner_id == u.id).one()
        histories = (
            s.query(TransferHistory)
            .filter(
                or_(
                    TransferHistory.from_account_id == u.id,
                    TransferHistory.to_account_id == u.id,
                )
            )
            .all()
        )
        favorites = (
            s.query(FavoriteAccount).filter(FavoriteAccount.owner_id == u.id).all()
        )
        session.close()


class AccountDetailTest(AccountTestCase):
    def test_account_detail_IDOR(self):  # 1
        s = self.Session()
        target_account = s.query(Account).filter(Account.owner_id == 2).one()
        result = self.simulate_get(
            f"/{target_account.number}/detail/", headers={"x-userid": "1"}
        )
        self.assertEqual(result.json["success"], False)
        try:
            self.assertNotEqual(
                result.json["data"]["account"]["number"], target_account.number
            )
        except KeyError:
            pass


class AccountTransferHistoryTest(AccountTestCase):
    def test_account_transfer_history_IDOR(self):  # 2
        s = self.Session()
        target_account = s.query(Account).filter(Account.owner_id == 2).one()
        result = self.simulate_get(
            f"/{target_account.number}/transfer-history/", headers={"x-userid": "1"}
        )
        self.assertEqual(result.json["success"], False)
        s.close()


class AccountTransferTest(AccountTestCase):
    def test_account_transfer_IDOR(self):  # 3
        s = self.Session()
        my_account = s.query(Account).filter(Account.owner_id == 1).one()
        target_account = s.query(Account).filter(Account.owner_id == 2).one()
        self.simulate_get(
            f"/transfer/{target_account.number}/{my_account.number}/1234/",
            headers={"x-userid": "1"},
        )
        s2 = self.Session()
        my_account_after = s2.query(Account).filter(Account.owner_id == 1).one()
        self.assertEqual(my_account_after.balance, my_account.balance)
        s.close()
        s2.close()

    def test_account_transfer_to_same_account(self):  # 4
        s = self.Session()
        my_account = s.query(Account).filter(Account.owner_id == 1).one()
        self.simulate_get(
            f"/transfer/{my_account.number}/{my_account.number}/1234/",
            headers={"x-userid": "1"},
        )
        s2 = self.Session()
        my_account_after = s2.query(Account).filter(Account.owner_id == 1).one()
        self.assertEqual(my_account_after.balance, my_account.balance)
        s.close()
        s2.close()

    def test_account_transfer_with_minus_amount(self):  # 5
        s = self.Session()
        my_account = s.query(Account).filter(Account.owner_id == 1).one()
        target_account = s.query(Account).filter(Account.owner_id == 2).one()
        self.simulate_get(
            f"/transfer/{my_account.number}/{target_account.number}/-1234/",
            headers={"x-userid": "1"},
        )
        s2 = self.Session()
        my_account_after = s2.query(Account).filter(Account.owner_id == 1).one()
        target_account_after = s2.query(Account).filter(Account.owner_id == 2).one()
        self.assertEqual(my_account_after.balance, my_account.balance)
        self.assertEqual(target_account_after.balance, target_account.balance)
        s.close()
        s2.close()

    def test_account_transfer_with_exceeding_amount(self):  # 6
        s = self.Session()
        my_account = s.query(Account).filter(Account.owner_id == 1).one()
        target_account = s.query(Account).filter(Account.owner_id == 2).one()
        self.simulate_get(
            f"/transfer/{my_account.number}/{target_account.number}/{my_account.balance + 1}/",
            headers={"x-userid": "1"},
        )
        s2 = self.Session()
        my_account_after = s2.query(Account).filter(Account.owner_id == 1).one()
        target_account_after = s2.query(Account).filter(Account.owner_id == 2).one()
        self.assertEqual(my_account_after.balance, my_account.balance)
        self.assertEqual(target_account_after.balance, target_account.balance)
        s.close()
        s2.close()

    def test_account_transfer_target_balance_leakage(self):  # 7
        s = self.Session()
        my_account = s.query(Account).filter(Account.owner_id == 1).one()
        target_account = s.query(Account).filter(Account.owner_id == 2).one()
        result = self.simulate_get(
            f"/transfer/{my_account.number}/{target_account.number}/{my_account.balance + 1}/",
            headers={"x-userid": "1"},
        )
        s.close()
        with self.assertRaises(KeyError):
            result.json["data"]["history"]["to_account"]["balance"]


if __name__ == "__main__":
    import unittest

    unittest.main()
