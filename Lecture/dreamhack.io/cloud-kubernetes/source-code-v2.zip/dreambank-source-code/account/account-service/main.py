import random
import json
import logging
import uuid

import falcon
import falcon.asgi

# import httpx

from models import Account, TransferHistory, FavoriteAccount

from sqlalchemy import exc, or_

from utils import make_return_message, max_body
from middlewares import *


class AccountCreateResource:
    def __init__(self):
        self.logger = logging.getLogger("AccountCreate." + __name__)

    @falcon.before(max_body(64 * 1024))
    async def on_post(self, req, resp):
        try:
            doc = req.context.doc
            user_id = req.context.user_id
        except AttributeError:
            raise falcon.HTTPBadRequest(
                title="Missing thing",
                description="A thing must be submitted in the request body.",
            )

        dup = True
        while dup:
            a = str(random.randrange(0, 10000)).rjust(4, "0")
            b = str(random.randrange(0, 10000)).rjust(4, "0")
            c = str(random.randrange(0, 10000)).rjust(4, "0")
            d = str(random.randrange(0, 10000)).rjust(4, "0")
            e = f"{a}-{b}-{c}-{d}"
            dup = req.context.session.query(Account).filter(Account.number == e).first()

        try:
            account = Account(
                number=e, nickname="Default Account", balance=0, owner_id=user_id
            )
            req.context.session.add(account)
            req.context.session.commit()
        except exc.IntegrityError:
            resp.status = falcon.HTTP_400
            resp.context.result = make_return_message(
                False, "You've already created an account"
            )
            return

        resp.status = falcon.HTTP_201
        resp.context.result = make_return_message(
            True, "Account creation success", {"account": {"number": account.number}}
        )


class AccountListResource:
    def __init__(self):
        self.logger = logging.getLogger("AccountList." + __name__)

    async def on_get(self, req, resp):
        try:
            user_id = req.context.user_id
        except AttributeError:
            raise falcon.HTTPBadRequest(
                title="Missing thing",
                description="A thing must be submitted in the request body.",
            )

        try:
            account = (
                req.context.session.query(Account)
                .filter(Account.owner_id == user_id)
                .one()
            )
        except Exception as e:
            resp.status = falcon.HTTP_404
            resp.context.result = make_return_message(False, "Account not found.")
            return

        resp.status = falcon.HTTP_200
        resp.context.result = make_return_message(
            True, data={"account": account.to_dict()}
        )


class AccountDetailResource:
    def __init__(self):
        self.logger = logging.getLogger("AccountDetail." + __name__)

    async def on_get(self, req, resp, account_number):
        try:
            user_id = req.context.user_id
        except AttributeError:
            raise falcon.HTTPBadRequest(
                title="Missing thing",
                description="A thing must be submitted in the request body.",
            )

        try:
            account = (
                req.context.session.query(Account)
                .filter(Account.number == account_number)
                .one()
            )
            pass
        except:
            resp.status = falcon.HTTP_404
            resp.context.result = make_return_message(False, "Account not found.")
            return

        resp.status = falcon.HTTP_200
        resp.context.result = make_return_message(
            True, data={"account": account.to_dict()}
        )


class TransferHistoryResource:
    def __init__(self):
        self.logger = logging.getLogger("TransferHistory." + __name__)

    async def on_get(self, req, resp, account_number):
        try:
            user_id = req.context.user_id
        except AttributeError:
            raise falcon.HTTPBadRequest(
                title="Missing thing",
                description="A thing must be submitted in the request body.",
            )

        try:
            histories = (
                req.context.session.query(TransferHistory)
                .join(
                    Account,
                    or_(
                        Account.id == TransferHistory.from_account_id,
                        Account.id == TransferHistory.to_account_id,
                    ),
                )
                .filter(Account.number == account_number)
                .order_by(TransferHistory.transfer_date.desc())
                .all()
            )
        except Exception as e:
            resp.status = falcon.HTTP_404
            resp.context.result = make_return_message(False, "Account not found.")
            return

        resp.status = falcon.HTTP_200
        resp.context.result = make_return_message(
            True, data={"histories": list(map(lambda x: x.to_dict(), histories))}
        )


class TransferResource:
    def __init__(self):
        self.logger = logging.getLogger("Transfer." + __name__)

    async def on_get(self, req, resp, account_number_from, account_number_to, amount):
        amount = int(amount)
        try:
            user_id = req.context.user_id
        except AttributeError:
            raise falcon.HTTPBadRequest(
                title="Missing thing",
                description="A thing must be submitted in the request body.",
            )

        try:
            a_account = (
                req.context.session.query(Account)
                .filter(Account.number == account_number_from)
                .one()
            )
            b_account = (
                req.context.session.query(Account)
                .filter(Account.number == account_number_to)
                .one()
            )
        except:
            resp.status = falcon.HTTP_404
            resp.context.result = make_return_message(False, "Account not found.")
            return

        a_balance = a_account.balance
        b_balance = b_account.balance

        a_account.balance = a_balance - amount
        b_account.balance = b_balance + amount

        transfer_history = TransferHistory(
            from_account_id=a_account.id,
            to_account_id=b_account.id,
            amount=amount,
        )

        req.context.session.add(a_account)
        req.context.session.add(b_account)
        req.context.session.add(transfer_history)
        req.context.session.commit()

        resp.status = falcon.HTTP_201
        resp.context.result = make_return_message(
            True, "Transfer successful.", {"history": transfer_history.to_dict()}
        )


# The app instance is an ASGI callable
app = falcon.asgi.App(
    middleware=[
        AuthMiddleware(),
        RequireJSON(),
        JSONTranslator(),
        DBSession(),
    ]
)

account_create = AccountCreateResource()
account_list = AccountListResource()
account_detail = AccountDetailResource()
transfer_history = TransferHistoryResource()
transfer = TransferResource()

app.add_route("/create/", account_create)
app.add_route("/list/", account_list)
app.add_route("/{account_number}/detail/", account_detail)
app.add_route("/{account_number}/transfer-history/", transfer_history)
app.add_route("/transfer/{account_number_from}/{account_number_to}/{amount}/", transfer)


if __name__ == "__main__":
    print("Run with uvicorn.")
