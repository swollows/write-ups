#!/bin/bash
python models.py create

