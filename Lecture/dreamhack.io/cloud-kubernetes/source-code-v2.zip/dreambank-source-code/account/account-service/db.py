import os
from sqlalchemy import create_engine

from settings import DEPLOY_ENV

engine = None

if DEPLOY_ENV == "dev":
    engine = create_engine("sqlite:///dev.db", echo=True)
elif DEPLOY_ENV == "prod":
    engine = create_engine(
        "mysql+pymysql://root:password@mysql/dreambank?charset=utf8", echo=True
    )
elif DEPLOY_ENV == "test":
    engine = create_engine("sqlite:///test.db", echo=False)

from sqlalchemy.orm import sessionmaker

Session = sessionmaker(bind=engine)
