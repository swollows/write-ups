#!/bin/bash
docker build . -t dreambank/account
