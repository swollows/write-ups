<template>
  <div style="margin: 0; padding: 0">
    <base-layout />
    <router-view />
  </div>
</template>

<script>
import BaseLayout from '@/layouts/BaseLayout'
export default {
  name: 'App',
  components: {
    BaseLayout
  }
}
</script>
