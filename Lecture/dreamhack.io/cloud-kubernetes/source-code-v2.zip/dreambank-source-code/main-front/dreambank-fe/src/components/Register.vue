<template>
  <section class="section is-small">
    <div class="container">
      <div class="columns">
        <div class="column is-half is-offset-one-quarter">
          <div class="box">
            <div class="title">
              Register
            </div>
            <div class="field">
              <label class="label">Email</label>
              <div class="control">
                <input v-model="email" class="input" :class="{ 'is-danger': errorMessageEmail }" type="email" placeholder="e.g. alex@example.com">
              </div>
              <p class="help is-danger is-6 subtitle">
                {{ errorMessageEmail }}
              </p>
            </div>
        
            <div class="field">
              <label class="label">Password</label>
              <div class="control">
                <input v-model="password" class="input" :class="{ 'is-danger': errorMessagePassword }" type="password" placeholder="********">
              </div>
              <p class="help is-danger is-6 subtitle">
                {{ errorMessagePassword }}
              </p>
            </div>
            <div class="field">
              <label class="label">Password Confirm</label>
              <div class="control">
                <input v-model="passwordConfirm" class="input" :class="{ 'is-danger': errorMessagePasswordConfirm }" type="password" placeholder="********">
              </div>
              <p class="help is-danger is-6 subtitle">
                {{ errorMessagePasswordConfirm }}
              </p>
            </div>

            <div class="field">
              <label class="label">First Name</label>
              <div class="control">
                <input v-model="firstName" class="input" :class="{ 'is-danger': errorMessageFirstName }" type="text" placeholder="John">
              </div>
              <p class="help is-danger is-6 subtitle">
                {{ errorMessageFirstName }}
              </p>
            </div>

            <div class="field">
              <label class="label">Last Name</label>
              <div class="control">
                <input v-model="lastName" class="input" :class="{ 'is-danger': errorMessageLastName }" type="text" placeholder="Doe">
              </div>
              <p class="help is-danger is-6 subtitle">
                {{ errorMessageLastName }}
              </p>
            </div>
            <hr>
            <button class="button is-info" @click="register">
              Register
            </button>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return  {
      errorMessageEmail: '',
      errorMessagePassword: '',
      errorMessagePasswordConfirm: '',
      errorMessageFirstName: '',
      errorMessageLastName: '',
      email: '',
      password: '',
      passwordConfirm: '',
      firstName: '',
      lastName: '',
    }
  },
  methods: {

    async register() {
      if (!this.email)
        this.errorMessageEmail = "Gimme an email"
      else
        this.errorMessageEmail = ""

      if (!this.password)
        this.errorMessagePassword = "Gimme a password"
      else
        this.errorMessagePassword = ""

      if (!this.passwordConfirm)
        this.errorMessagePasswordConfirm = "Gimme a password"
      else
        this.errorMessagePasswordConfirm = ""

      if (!this.firstName)
        this.errorMessageFirstName = "Gimme a firstName"
      else
        this.errorMessageFirstName = ""

      if (!this.lastName)
        this.errorMessageLastName = "Gimme a lastName"
      else
        this.errorMessageLastName = ""

      if (!this.password || !this.email || !this.passwordConfirm || !this.firstName || !this.lastName) return

      if (this.passwordConfirm != this.password) {
        this.errorMessagePasswordConfirm = "password does not match"
        return
      }

      // should set axios base url
      try {
        const res = await axios.post('/api/auth/register', {"email": this.email, "password": this.password, "password_confirm": this.passwordConfirm, "first_name": this.firstName, "last_name": this.lastName})
        res
        this.$toast.success('Register successful!', { position: 'top-right' });
        this.$router.push({ name: 'login' });
      } catch (e) {
        this.$toast.error(e.response.data.message, { position: 'top-right' });
        console.log(e.response)
        if (e.response.data.data.email) {
          this.errorMessageEmail = e.response.data.data.email[0]
        }

        if (e.response.data.data.password) {
          this.errorMessagePassword = e.response.data.data.password[0]
        }

        if (e.response.data.data.first_name) {
          this.errorMessageFirstName = e.response.data.data.first_name[0]
        }

        if (e.response.data.data.last_name) {
          this.errorMessageLastName = e.response.data.data.last_name[0]
        }
      }
    }
  }
}
</script>
