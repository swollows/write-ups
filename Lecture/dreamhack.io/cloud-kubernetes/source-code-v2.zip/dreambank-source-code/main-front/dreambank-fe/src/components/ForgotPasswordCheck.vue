<template>
  <section class="section is-small">
    <div class="container">
      <div class="columns">
        <div class="column is-half is-offset-one-quarter">
          <div class="box">
            <div class="title">
              Forgot password (Check pin code)
            </div>
            <div class="field">
              <label class="label">Pin Code</label>
              <div class="control">
                <input v-model="pin" class="input" :class="{ 'is-danger': errorMessagePin }" type="text" placeholder="123456">
              </div>
              <p class="help is-danger is-6 subtitle">
                {{ errorMessagePin }}
              </p>
            </div>
            <div class="field">
              <label class="label">Password</label>
              <div class="control">
                <input v-model="password" class="input" :class="{ 'is-danger': errorMessagePassword }" type="password" placeholder="********">
              </div>
              <p class="help is-danger is-6 subtitle">
                {{ errorMessagePassword }}
              </p>
            </div>
            <div class="field">
              <label class="label">Password Confirm</label>
              <div class="control">
                <input v-model="passwordConfirm" class="input" :class="{ 'is-danger': errorMessagePasswordConfirm }" type="password" placeholder="********">
              </div>
              <p class="help is-danger is-6 subtitle">
                {{ errorMessagePasswordConfirm }}
              </p>
            </div>
        
            <button class="button is-info" @click="resetPassword">
              Reset password
            </button>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import axios from 'axios';
import store from '@/store'

export default {
  data() {
    return  {
      errorMessagePin: '',
      password_reset_token: '',
      pin: '',
      email: '',
      password: '',
      passwordConfirm: '',
      errorMessagePasswordConfirm: '',
      errorMessagePassword: '',
    }
  },
  created() {
    this.password_reset_token = store.state.passwordResetToken || this.$route.query.password_reset_token
    this.email = store.state.passwordResetEmail || this.$route.query.email


    if(!this.password_reset_token) {
      this.$toast.error("Password reset token not provided.", { position: 'top-right'} )
      this.$router.push({name: 'forgot-password'})
      return
    }

    if (!this.email) {
      this.$toast.error("Email not provided", { position: 'top-right' })
      this.$router.push({name: 'forgot-password' })
      return
    }


  },
  methods: {

    async resetPassword() {
      if (!this.pin)
        this.errorMessagePin = "Gimme an pin code"
      else
        this.errorMessagePin = ""

      if (!this.password)
        this.errorMessagePassword = "Gimme a password"
      else
        this.errorMessagePassword = ""

      this.errorMessagePasswordConfirm = ''
      if (this.passwordConfirm != this.password) {
        this.errorMessagePasswordConfirm = "password does not match"
        return
      }

      if (!this.password || !this.email || !this.pin) return


      // should set axios base url
      try {
        const res = await axios.post('/api/auth/reset-password-check', {"email": this.email, password_reset_token: this.password_reset_token, pin: this.pin, password: this.password})
        console.log(res.data)

        delete store.state['passwordResetToken']
        delete store.state['passwordResetEmail']

        this.$toast.success('Password reset successful', { position: 'top-right' });
        this.$router.push({ name: 'login' })
      } catch (e) {
        if (e.response.data.data.password_reset_token) {
          this.$toast.error(e.response.data.data.password_reset_token[0], { position: 'top-right'} )
          this.$router.push({name: 'forgot-password'})
          return
        }

        if (e.response.data.data.password) {
          this.errorMessagePassword = e.response.data.data.password[0]
        }
        if (e.response.data.data.pin) {
          this.errorMessagePin = e.response.data.data.pin[0]
        }
        
        this.$toast.error(e.response.data.message, { position: 'top-right' });
      }
    }
  }
}
</script>
