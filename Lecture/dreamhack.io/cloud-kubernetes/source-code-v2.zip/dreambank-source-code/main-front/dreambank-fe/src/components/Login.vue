<template>
  <section class="section is-small">
    <div class="container">
      <div class="columns">
        <div class="column is-half is-offset-one-quarter">
          <div class="box">
            <div class="title">
              Login
            </div>
            <div class="field">
              <label class="label">Email</label>
              <div class="control">
                <input v-model="email" class="input" :class="{ 'is-danger': errorMessageEmail }" type="email" placeholder="e.g. alex@example.com">
              </div>
              <p class="help is-danger is-6 subtitle">
                {{ errorMessageEmail }}
              </p>
            </div>
        
            <div class="field">
              <label class="label">Password</label>
              <div class="control">
                <input v-model="password" class="input" :class="{ 'is-danger': errorMessagePassword }" type="password" placeholder="********">
              </div>
              <p class="help is-danger is-6 subtitle">
                {{ errorMessagePassword }}
              </p>
            </div>
            <router-link to="forgot-password">
              <a class="subtitle is-6" style="color: blue">Forgot password?</a>
            </router-link>
            <hr>
        
            <button class="button is-light" @click="login">
              Login
            </button>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import axios from 'axios';
import store from '@/store'

export default {
  data() {
    return  {
      errorMessageEmail: '',
      errorMessagePassword: '',
      email: '',
      password: '',
    }
  },
  methods: {

    async login() {
      /*
       * CS Account - 1: csadmin1@dreambank.io / iwannagohome1234
       */
      if (!this.email)
        this.errorMessageEmail = "Gimme an email"
      else
        this.errorMessageEmail = ""


      if (!this.password)
        this.errorMessagePassword = "Gimme a password"
      else
        this.errorMessagePassword = ""

      if (!this.password || !this.email) return

      try {
        const res = await axios.post('/api/auth/login', {"email": this.email, "password": this.password})
        localStorage.authToken = res.data.data.token
        localStorage.email = this.email
        store.state.authToken = localStorage.authToken
        store.state.email = localStorage.email
        this.$toast.success('Login successful!!', { position: 'top-right' });
        if (this.$route.query.return_url)
          window.location.href = this.$route.query.return_url
        else
          this.$router.push({ name: 'main' });
      } catch (e) {
        this.$toast.error(e.response.data.message, { position: 'top-right' });
        if (e.response.data.data.email) {
          this.errorMessageEmail = e.response.data.data.email[0]
        }

        if (e.response.data.data.password) {
          this.errorMessagePassword = e.response.data.data.password[0]
        }
      }
    }
  }
}
</script>
