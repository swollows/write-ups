import { createWebHistory, createRouter } from "vue-router";

import Main from '@/components/Main'
import Login from '@/components/Login'
import Register from '@/components/Register'
import Logout from '@/components/Logout'
import ForgotPassword from '@/components/ForgotPassword'
import ForgotPasswordCheck from '@/components/ForgotPasswordCheck'

export default createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'main',
      component: Main
    },
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/forgot-password',
      name: 'forgot-password',
      component: ForgotPassword
    },
    {
      path: '/forgot-password-check',
      name: 'forgot-password-check',
      component: ForgotPasswordCheck
    },
    {
      path: '/logout',
      name: 'lgoout',
      component: Logout
    },
    {
      path: '/register',
      name: 'register',
      component: Register
    }
  ],
});
