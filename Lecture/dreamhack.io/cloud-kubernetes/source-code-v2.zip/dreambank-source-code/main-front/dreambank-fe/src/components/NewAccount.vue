<template>
  <section class="section is-small">
    <div class="container">
      <div class="columns">
        <div class="column is-half is-offset-one-quarter">
          <div class="box" style="padding: 0;">
            <img src="https://dreamhack-media.s3.ap-northeast-2.amazonaws.com/uploads/externals/dreambank/main.png">
            <div style="padding: 1.5rem">
              <div class="columns">
                <div class="column">
                  <div class="title has-text-centered">
                    Welcome!
                  </div>
                  <div class="padding"></div>
                  <div class="subtitle is-5 has-text-centered">
                    Account not found.<br><span v-if="isNotLogin">Register or Login to create your new account for free!</span>
                  </div>
                  <div class="padding"></div>
                  <div class="field">
                    <div class="control buttons is-centered is-fullwidth">
                      <router-link v-if="isNotLogin" to="register" style="width: 50%">
                        <button class="button is-info is-fullwidth is-medium">
                          Register
                        </button>
                      </router-link>
                      <button v-else-if="isNoAccount" class="button is-info is-fullwidth is-medium" @click="createAccount">
                        Create your account.
                      </button>
                    </div>
                  </div>
                  <div class="padding"></div>
                  <div class="padding"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import axios from 'axios';
import store from '@/store'

export default {
  data() {
    return  {
    }
  },
  computed: {
    isNoAccount() {
      return !store.state.accountNumber
    },
    isNotLogin() {
      return !store.state.authToken
    },
    accountNumber() {
      return store.state.accountNumber
    },
  },
  methods: {
    async createAccount() {
      try {
        const res = await axios.post('/api/account/create', {}, {headers: {Authorization: `Bearer ${store.state.authToken}`}})
        store.state.accountNumber = res.data.data.account.number
        this.$toast.success(res.data.message, { position: 'top-right' });
        this.$router.push({ name: 'main' });
      } catch (e) {
        this.$toast.error(e.response.data.message, { position: 'top-right' });
      }
    }
  }
}
</script>

<style scoped>
.padding {
  padding: 0.2rem;
}
</style>
