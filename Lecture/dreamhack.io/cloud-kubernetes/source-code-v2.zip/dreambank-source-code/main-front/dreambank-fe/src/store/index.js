import { reactive } from 'vue'
export default {
  state: reactive({
    authToken: '',
    email: '',
  })
}