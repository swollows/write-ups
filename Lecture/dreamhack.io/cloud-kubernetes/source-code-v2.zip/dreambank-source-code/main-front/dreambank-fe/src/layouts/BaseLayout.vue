<template>
  <my-header />
</template>

<script>
import MyHeader from '@/components/MyHeader'

export default {
  components: {
    MyHeader
  }
}
</script>
