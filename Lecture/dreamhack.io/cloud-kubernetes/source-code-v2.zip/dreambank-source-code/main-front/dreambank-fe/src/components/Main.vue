<template>
  <new-account v-if="isNotLoginOrNoAccount" />
  <account v-else />
</template>

<script>
import axios from 'axios'
import store from '@/store'
import Account from '@/components/Account'
import NewAccount from '@/components/NewAccount'

export default {
  components: { NewAccount, Account },
  computed: {
    isNotLoginOrNoAccount() {
      return !store.state.authToken || !store.state.accountNumber
    },
    accountNumber() {
      return store.state.accountNumber
    },
  },
  async created() {
    const res = await axios.get('/api/account/list/', {headers: {Authorization: `Bearer ${store.state.authToken}`}})
    store.state.accountNumber = res.data.data.account.number
  },
  methods: {
    checkLoginState(event) {
      if(this.isNotLogin) {
        event.preventDefault()
        this.$toast.error("You should login frist!", { position: 'top-right' })
        this.$router.push({ name: 'login' })

      }
    }
  }
}
</script>
