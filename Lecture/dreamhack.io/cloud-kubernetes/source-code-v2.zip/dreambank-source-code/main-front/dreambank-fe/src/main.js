import { createApp } from 'vue'
import router from './router'
import App from './App.vue'
import Toaster from '@meforma/vue-toaster';
import store from '@/store'

store.state.authToken = localStorage.authToken
store.state.email = localStorage.email

require('@/assets/main.scss');

const app = createApp(App)
// https://vuejsdevelopers.com/topics/vue-router/
app.use(router)
app.use(Toaster)
app.mount('#app')
