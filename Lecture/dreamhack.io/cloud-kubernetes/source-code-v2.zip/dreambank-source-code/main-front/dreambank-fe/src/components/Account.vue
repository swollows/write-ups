<template>
  <section class="section is-small">
    <div class="container">
      <div class="columns">
        <div class="column is-half is-offset-one-quarter">
          <div class="title nomargin">
            {{ accountDetail.nickname }}
          </div>
          <div class="columns nomargin">
            <div class="column is-two-third">
              <span class="subtitle"><b>Account number</b><br>{{ accountDetail.number }}</span>
            </div>
            <div class="column has-text-right">
              <span class="subtitle"><b>Balance</b><br>${{ accountDetail.balance }}</span>
            </div>
          </div>
          <div class="box">
            <!-- amount of money -->
            <div class="field">
              <div class="control has-icons-left is-expanded">
                <input v-model="transferAmount" class="input is-large" :class="{ 'is-danger': transferAmountErrorMessage }" type="number" placeholder="Amount" style="text-align: right;">
                <span class="icon is-medium is-left">
                  <i class="fas fa-dollar-sign fa-lg"></i>
                </span>
                <p class="help is-danger is-5 subtitle">
                  {{ transferAmountErrorMessage }}
                </p>
              </div>                        
            </div>
            <!-- where you want to send -->
            <div class="field">
              <div class="control has-icons-left is-expanded">
                <input v-model="transferToAccountNumber" class="input is-large" :class="{ 'is-danger': transferToAccountNumberErrorMessage }" type="text" placeholder="Account number" style="text-align: right;">
                <span class="icon is-medium is-left">
                  <i class="fas fa-people-arrows fa-lg"></i>
                </span>
                <p class="help is-danger is-5 subtitle">
                  {{ transferToAccountNumberErrorMessage }}
                </p>
              </div>
            </div>
            <div class="field">
              <div class="control buttons">
                <button class="button is-info is-fullwidth is-medium" @click="transfer">
                  Transfer
                </button>
              </div>
            </div>
                    
            <hr>
            <div class="tabs">
              <ul>
                <li class="is-active">
                  <a>Transfer history</a>
                </li>
                <!-- TODO (v1.1) <li><a>Favorites</a></li> -->
              </ul>
            </div>
            <!-- transfer history -->
            <div v-for="t in transferHistories" :key="t.id" class="box transfer-history-box">
              <div v-if="t.from_account.number !== accountNumber" class="is-deposit-or-withdraw is-deposit">
                Deposit
              </div>
              <div v-else class="is-deposit-or-withdraw is-withdraw">
                Withdraw
              </div>
              <table class="table">
                <tr>
                  <td><b>Date</b></td><td class="last has-text-right">
                    {{ t.transfer_date }}
                  </td>
                </tr>
                <tr v-if="t.from_account.number !== accountNumber">
                  <td><b>From</b></td><td class="last has-text-right">
                    {{ t.from_account.number }}
                  </td>
                </tr>
                <tr v-else>
                  <td><b>To</b></td><td class="last has-text-right">
                    {{ t.to_account.number }}
                  </td>
                </tr>
                <tr>
                  <td class="td-last">
                    <b>Amount</b>
                  </td><td class="td-last last has-text-right">
                    <i class="fas fa-dollar-sign fa-large"></i> {{ t.amount }}
                  </td>
                </tr>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import axios from 'axios';
import store from '@/store'
export default {
  data() {
    return {
      accountNumber: store.state.accountNumber,
      accountDetail: {},
      transferHistories: {},
      transferAmount: "",
      transferAmountErrorMessage: "",
      transferToAccountNumber: "",
      transferToAccountNumberErrorMessage: ""
    }
  },
  async created() {
    this.accountDetail = await this.getDetail(this.accountNumber)
    this.transferHistories = await this.getTransferHistories(this.accountNumber)
    this.transferAmount = this.$route.query.transferAmount
    this.transferToAccountNumber = this.$route.query.transferToAccountNumber
  },
  methods: {
    async getDetail (accountNumber) {
      try {
        const res = await axios.get(`/api/account/${accountNumber}/detail`, {headers: {Authorization: `Bearer ${store.state.authToken}`}})
        return res.data.data.account
      } catch (e) {
        this.$toast.error(e.response.data.message, { position: 'top-right' });
      }
    },
    async transfer () {
      this.transferAmountErrorMessage = ''
      this.transferToAccountNumberErrorMessage = ''

      if (!this.transferAmount) {
        this.transferAmountErrorMessage = "Invalid amount"
      }

      if (!this.transferToAccountNumber || !this.transferToAccountNumber.match(/^\d{4}-\d{4}-\d{4}-\d{4}$/)) {
        this.transferToAccountNumberErrorMessage = "Invalid account number"
      }

      if (this.transferToAccountNumberErrorMessage || this.transferAmountErrorMessage) {
        return
      }

      try {
        const res = await axios.get(`/api/account/transfer/${this.accountNumber}/${this.transferToAccountNumber}/${this.transferAmount}`, {headers: {Authorization: `Bearer ${store.state.authToken}`}})
        this.$toast.success(res.data.message, { position: 'top-right' })
        this.transferHistories.unshift(res.data.data.history)
        this.accountDetail = await this.getDetail(this.accountNumber)
        return res.data.data.account
      } catch (e) {
        if (e.response.data.message.indexOf("Account") != -1) {
          this.transferToAccountNumberErrorMessage = "Account not found."
        }
        this.$toast.error(e.response.data.message, { position: 'top-right' });
      }
    },
    async getTransferHistories (accountNumber) {
      try {
        const res = await axios.get(`/api/account/${accountNumber}/transfer-history`, {headers: {Authorization: `Bearer ${store.state.authToken}`}})
        return res.data.data.histories
      } catch (e) {
        this.$toast.error(e.response.data.message, { position: 'top-right' });
      }
    }
  }
}
</script>

<style scoped>
.tabs li.is-active a {
  border-bottom-color: #6b7af7;
  color: #6b7af7;
  font-weight: bold;
}

.transfer-history-box {
  box-shadow: 0 0 0 0;
  background: #f0f0f5;
}

.transfer-history-box table {
  background: #f0f0f5;
}

.td-last {
  border: 0;
}

.is-deposit-or-withdraw {
  font-size: 1.3rem;
  font-weight: bold;
}

.is-deposit {
  color: #6b7af7;
}

.is-withdraw {
  color: #e60f6c;
}
</style>