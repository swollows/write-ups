<template>
  <div></div>
</template>

<script>
import axios from 'axios';
import store from '@/store'

export default {
  created() {
    window.localStorage.authToken = undefined
    axios.get("/api/logout")
    localStorage.authToken = ''
    localStorage.email = ''
    for (let x in store.state) {
      delete store.state[x]
    }
    this.$toast.success('Logout successful!!', { position: 'top-right' });
    this.$router.push({ name: 'main' });
  }
}
</script>
