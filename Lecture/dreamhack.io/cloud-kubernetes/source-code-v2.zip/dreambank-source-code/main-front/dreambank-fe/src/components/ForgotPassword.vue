<template>
  <section class="section is-small">
    <div class="container">
      <div class="columns">
        <div class="column is-half is-offset-one-quarter">
          <div class="box">
            <div class="title">
              Forgot password
            </div>
            <div class="field">
              <label class="label">Email</label>
              <div class="control">
                <input v-model="email" class="input" :class="{ 'is-danger': errorMessageEmail }" type="email" placeholder="e.g. alex@example.com">
              </div>
              <p class="help is-danger is-6 subtitle">
                {{ errorMessageEmail }}
              </p>
            </div>
        
            <button class="button is-info" @click="requestPinCode">
              Request a pin code!
            </button>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import axios from 'axios';
import store from '@/store'

export default {
  data() {
    return  {
      errorMessageEmail: '',
      email: '',
    }
  },
  methods: {

    async requestPinCode() {
      if (!this.email)
        this.errorMessageEmail = "Gimme an email"
      else
        this.errorMessageEmail = ""

      if (!this.email) return

      // should set axios base url
      try {
        const res = await axios.post('/api/auth/reset-password', {"email": this.email})
        store.state.passwordResetToken = res.data.data.password_reset_token
        store.state.passwordResetEmail = this.email
        this.$toast.success('Pin code is sent!', { position: 'top-right' });
        this.$router.push({ name: 'forgot-password-check', query: {password_reset_token: store.state.passwordResetToken, email: this.email } })
      } catch (e) {
        this.$toast.error(e.response.data.message, { position: 'top-right' });
      }
    }
  }
}
</script>
