<template>
  <nav class="navbar is-white topNav">
    <div class="container">
      <div class="navbar-brand">
        <router-link class="navbar-item" to="/">
          <img src="https://dreamhack-media.s3.ap-northeast-2.amazonaws.com/uploads/externals/dreambank/logo.png" width="112" height="28">
        </router-link>
        <div class="navbar-burger burger" data-target="topNav">
        </div>
      </div>
      <div id="topNav" class="navbar-menu">
        <!-- TODO -->
        <div class="navbar-start">
          <a class="navbar-item" href="/community" @click="checkLoginState">Community</a>
          <a class="navbar-item" href="/community/help" @click="checkLoginState">Help</a>
        </div>
      </div>
      <div class="navbar-end">
        <div class="navbar-item">
          <div v-if="isNotLogin" class="buttons">
            <router-link class="button is-info" to="/register">
              <strong>Register</strong>
            </router-link>
            <router-link class="button is-light" to="/login">
              <strong>Login</strong>
            </router-link>
          </div>
          <div v-else class="buttons">
            <a class="button" @click="notImplementedMypage">
              <svg style="height: 1em; margin: 0 0.3em 0 -0.3em;" aria-hidden="true" focusable="false" data-prefix="dh" data-icon="person" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" class="svg-inline--fa fa-person fa-w-16 fa-2x"><path fill="currentColor" d="M26.4 26.8h-.3c-.3-.1-.5-.4-.5-.6-.2-3.1-2.7-5.8-6.3-6.8-.3-.1-.5-.3-.5-.6-.1-.3.1-.6.3-.7 1.2-.9 1.9-2.2 1.9-3.7V13c0-2.5-2.1-4.6-4.6-4.6-2.5 0-4.6 2.1-4.6 4.6v1.3c0 1.4.7 2.8 1.9 3.7.2.2.3.5.3.7-.1.3-.3.5-.5.6-3.6 1-6.1 3.7-6.3 6.8 0 .3-.2.5-.5.6-.3.1-.6 0-.8-.2-2.7-2.8-4.2-6.4-4.2-10.3 0-3.9 1.5-7.6 4.3-10.4s6.5-4.3 10.4-4.3c8.1 0 14.8 6.6 14.8 14.8 0 3.8-1.5 7.5-4.2 10.3-.2.1-.4.2-.6.2zm-5.5-8.5c3 1.2 5.1 3.4 5.9 6.1 1.8-2.3 2.7-5.1 2.7-8.1 0-7.3-5.9-13.2-13.2-13.2C12.8 3.1 9.5 4.5 7 7s-3.9 5.8-3.9 9.4c0 2.9 1 5.8 2.7 8.1.8-2.7 2.9-4.9 5.9-6.1-.9-1.1-1.5-2.5-1.5-3.9V13c0-3.4 2.7-6.1 6.1-6.1s6.1 2.7 6.1 6.1v1.3c0 1.5-.5 2.9-1.5 4zm-4.6 12.8c-4 0-7.8-1.6-10.6-4.5-.1-.2-.2-.4-.2-.6.3-3.4 2.6-6.3 6.2-7.7-.9-1.1-1.5-2.5-1.5-3.9V13c0-3.4 2.7-6.1 6.1-6.1 3.4 0 6.1 2.7 6.1 6.1v1.3c0 1.5-.5 2.9-1.5 3.9 3.5 1.4 5.9 4.3 6.2 7.7 0 .2-.1.4-.2.6-2.8 3-6.5 4.6-10.6 4.6zm-9.2-5.3c2.5 2.4 5.8 3.8 9.3 3.8 3.5 0 6.8-1.3 9.3-3.8-.4-3-2.8-5.5-6.3-6.5-.3-.1-.5-.3-.5-.6-.1-.3.1-.6.3-.7 1.2-.9 1.9-2.2 1.9-3.7V13c0-2.5-2.1-4.6-4.6-4.6-2.5 0-4.6 2.1-4.6 4.6v1.3c0 1.4.7 2.8 1.9 3.7.2.2.3.5.3.7-.1.3-.3.5-.5.6-3.7 1-6.1 3.5-6.5 6.5z" class="" />></svg>
              <strong>{{ email }}</strong>
            </a>
            <router-link class="button is-light" to="/logout">
              <strong>Logout</strong>
            </router-link>
          </div>
        </div>
      </div>
    </div>
  </nav>
</template>

<script>
import store from '@/store'
export default {
  computed: {
    isNotLogin() {
      return !store.state.authToken
    },
    email() {
      return store.state.email
    },
  },
  methods: {
    notImplementedMypage() {
      this.$toast.error("Mypage - not implemented feature.", { position: 'top-right' })
    },
    checkLoginState(event) {
      if(this.isNotLogin) {
        event.preventDefault()
        this.$toast.error("You should login frist!", { position: 'top-right' })
        this.$router.push({ name: 'login' })

      }
    }
  }
}
</script>

<style>
html,body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
            background: #f0f0f5 !important;
        }
        .footer {
            padding: 0em;
            background-color: #f0f0f5;
        }
        .container .columns {
            margin: 3rem 0;
        }


        .navbar-item {
          color: #3f3f3f !important;
          font-weight: 700 !important;
          color: rgba(0,0,0,.5) !important;
        }

        .navbar-item:hover {
          color: rgba(0,0,0,1) !important;
        }


    .nomargin {
      margin: 0 !important;
    }

    td.last {
      width: 100%;
    }
</style>
