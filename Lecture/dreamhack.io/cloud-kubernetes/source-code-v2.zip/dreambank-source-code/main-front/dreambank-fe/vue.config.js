module.exports = {
  devServer: {
    proxy: {
      '/api': {
        target: 'http://172.30.1.9:8000',
        ws: true,
        changeOrigin: true
      },
    }
  }
}
