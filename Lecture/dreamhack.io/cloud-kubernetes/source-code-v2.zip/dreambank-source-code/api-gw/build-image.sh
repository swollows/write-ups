#!/bin/bash
docker build . -t dreambank/api-gw
