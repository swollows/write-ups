https://kubernetes.io/docs/tasks/run-application/run-single-instance-stateful-application/

- get mysql shell
    - `kubectl run -it --rm --image=mysql:8.0 --restart=Never mysql-client sh`
