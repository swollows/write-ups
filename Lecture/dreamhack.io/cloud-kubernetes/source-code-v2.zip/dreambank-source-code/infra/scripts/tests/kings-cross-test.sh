#!/bin/bash

NODE_IP=$(minikube kubectl -- get nodes -o json | jq -r '.items[] | .status .addresses[] | select(.type=="InternalIP") | .address')
curl http://$NODE_IP:30080/api/auth/register -X POST -H 'Content-Type: application/json' --data '{"email": "hi@theori.io", "password": "theori1234", "password_confirm": "theori1234"}'
echo ""

TOKEN=$(curl http://$NODE_IP:30080/api/auth/login -X POST -H 'Content-Type: application/json' --data '{"email": "hi@theori.io", "password": "theori1234"}' | jq -r ".data .token")
echo "Token: $TOKEN"

./gw-test.py $TOKEN
