#!/bin/bash
minikube kubectl -- rollout restart deployment dreambank-api-gw-deployment
minikube kubectl -- rollout restart deployment dreambank-kings-cross-deployment
minikube kubectl -- rollout restart deployment dreambank-community-deployment
minikube kubectl -- rollout restart deployment dreambank-account-deployment
