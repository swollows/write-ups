#!/bin/bash
minikube kubectl -- get nodes -o json | jq -r '.items[] | .status .addresses[] | select(.type=="InternalIP") | .address'
