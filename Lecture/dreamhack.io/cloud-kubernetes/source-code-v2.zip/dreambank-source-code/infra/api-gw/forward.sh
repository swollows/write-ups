#!/bin/bash
minikube kubectl -- port-forward --address 0.0.0.0 svc/dreambank-api-gw-service 8000:30080
