# magic_of_solidity

### Author

jinu.eth < https://twitter.com/lj1nu >

### Description

![img](https://cdn.pixabay.com/photo/2023/02/06/10/57/ai-generated-7771755_1280.jpg)

Are you a sorcerer? Cast your magic and retrieve the flag.  
base code: https://github.com/chainflag/solidity-ctf-template
